public class HLine extends VectorObject {
    private int hLength;

    public HLine(int id, int x, int y,int hLength) {
        super (id, x, y);
        this.hLength = hLength;
    }

    @Override 
    public void draw(char [][] matrix) {
        for (int i = x; i < (x + hLength); i ++) {
            matrix[y][i] = '*';
        }
    }
}
