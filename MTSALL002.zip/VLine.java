public class VLine extends VectorObject {
    private int vLength;

    public VLine(int id, int x, int y,int vLength) {
        super (id, x, y);
        this.vLength = vLength;
    }

    @Override 
    public void draw(char [][] matrix) {
        for (int j = y; j < (y + vLength); j ++) {
            matrix[j][x] = '*';
        }
    }
}
